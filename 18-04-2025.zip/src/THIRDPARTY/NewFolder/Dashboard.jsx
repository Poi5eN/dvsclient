import React from 'react'
import SchoolDetails from '../SchoolDetails'

const Dashboard = () => {
  return (
    <div>
        <SchoolDetails/>
    </div>
  )
}

export default Dashboard