import React from 'react'
import AllStudent from '../AllStudent'

const ThirdpartStudent = () => {
  return (
    <div>
        <AllStudent/>
    </div>
  )
}

export default ThirdpartStudent