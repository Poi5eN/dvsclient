import React from 'react'
import DynamicFormFileds from './PhotoCard/DynamicFormFileds'

const Photo = () => {
  return (
    <DynamicFormFileds
            buttonLabel={'Save'}
       
              />
  )
}

export default Photo