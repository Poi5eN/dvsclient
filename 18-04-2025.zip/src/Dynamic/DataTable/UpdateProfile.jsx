import React from 'react'

const UpdateProfile = () => {
  return (
    <div>
      <h1>UpdateProfile</h1>
    </div>
  )
}

export default UpdateProfile
