import React from 'react'
import Create_Student from './Create_Student'

const MyStudent = () => {
  return (
    <div> 
<Create_Student/>
    </div>
  )
}

export default MyStudent