import React from "react";

const Subjects = () => {
  return <div>Subjects</div>;
};

export default Subjects;
