import React from 'react'

const ParentContact = () => {
  return (
    <div>ParentContact</div>
  )
}

export default ParentContact