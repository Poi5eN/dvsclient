import React from 'react'

const ParentNotification = () => {
  return (
    <div>ParentNotification</div>
  )
}

export default ParentNotification