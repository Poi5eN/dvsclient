import React from 'react'

const Events = () => {
  return (
    <div>Events</div>
  )
}
export default Events