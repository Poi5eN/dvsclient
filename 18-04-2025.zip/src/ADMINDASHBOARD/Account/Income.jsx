import React from 'react'

const Income = () => {
  return (
    <div>Income</div>
  )
}

export default Income

// import React from 'react'
// import Create_Income from './Create_Income'

// function Income() {
//   return (
//     <div>
//     <Create_Income/>
//     </div>
//   )
// }

// export default Income