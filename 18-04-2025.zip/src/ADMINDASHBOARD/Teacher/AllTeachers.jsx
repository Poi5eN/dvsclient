import React from "react";
import Create_Teacher from "./Create_Teacher";


const AllTeachers = () => {
  return (
    <div>
    <Create_Teacher/>
    </div>
   
  );
};

export default AllTeachers;
