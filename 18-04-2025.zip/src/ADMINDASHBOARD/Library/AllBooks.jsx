import React from 'react'

import Create_Book from './Create_Book'

const AllBooks = () => {
  return (
    <div>
      <Create_Book/>
    </div>
  )
}

export default AllBooks
