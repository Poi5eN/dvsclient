import React from 'react'
import Create_Staff from './Staff/Create_Staff'

const Staff = () => {
  return (
    <>
     <Create_Staff/>
      
    </>
  )
}

export default Staff

