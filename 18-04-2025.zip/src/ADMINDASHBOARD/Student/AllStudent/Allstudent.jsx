import React from 'react';


import CreateStudent from './CreateStudent';

function Allstudent() {
  return (
    <div>
        <CreateStudent/>
    </div>
  );
}
export default Allstudent;

