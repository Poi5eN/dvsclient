import React from 'react'
import Hero from './Page/Fetaure/Hero'
import Dashboard from './Page/Fetaure/Dashboard'
import Services from './Page/Fetaure/Services'
import Screen from './Page/Fetaure/Screen'
import Graph from './Page/Fetaure/Graph'

const Feature = () => {
  return (
    <div className='bg-white'>
     
    <Hero/>
    <Dashboard/>
    <Services/>
    <Screen/>
    <Graph/>
    </div>
  )
}

export default Feature
