import React from 'react'
import CreateSell from './CreateSell'
const Sales = () => {
  return (
    <div>
    <CreateSell/>
    </div>
  )
}

export default Sales