import React from 'react'
import Create_Stocks from './Create_Stocks'

const Sales = () => {
  return (

    <div>
      <Create_Stocks/>
     
    </div>
   
  )
}

export default Sales
