import React from 'react'
import Create_Subjects from './Create_Subjects'

const AllSubjects = () => {
  return (
    <div>
      <Create_Subjects/>
    </div>
  )
}

export default AllSubjects
