import React from 'react'
import Create_Classes from './Create_Classes'

const AllClasses = () => {
  return (
    <div>
      <Create_Classes/>
    </div>
  )
}

export default AllClasses
