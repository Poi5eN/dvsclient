import React from 'react'
import IssueBookCreate from './IssueBook/IssueBookCreate'

const IssuedBook = () => {
  return (
    <div>
      <IssueBookCreate/>
    </div>
  )
}

export default IssuedBook