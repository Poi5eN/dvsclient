import React from 'react'
import CreatePayment from './CreatePayment'

const Payment = () => {
  return (
   <CreatePayment/>
  )
}

export default Payment