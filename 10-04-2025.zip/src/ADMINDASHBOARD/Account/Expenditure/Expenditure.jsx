import React from 'react'
import Create_Expenditure from './Create_Expenditure'
const Expenditure = () => {
  return (
    <div>
    <Create_Expenditure/>
    </div>
  )
}
export default Expenditure;
